from project.motorcycle import Motorcycle


class CrossMotorcycle(Motorcycle):
    pass